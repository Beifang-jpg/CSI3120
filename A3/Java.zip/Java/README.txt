CSI3120-A3-Hongru Wang-300140660

The data structure is stack. I was using VScode for this code so I was using
analyzer/ input.txt or this will bring bugs. This is the third version of my work. 
The previous one have some small problem that unable to get expected feedback on 
few input files so it was improved by using stack. 

Also, I tried the 10 files and their output is same the expected one. 